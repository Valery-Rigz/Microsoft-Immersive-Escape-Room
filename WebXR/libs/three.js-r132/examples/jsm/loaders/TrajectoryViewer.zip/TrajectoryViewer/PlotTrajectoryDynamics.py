import argparse
import os
import sys
import numpy as np
import matplotlib.pyplot as plt

# This script is intended to be used in conjunction with the tool TrajectoryViewer.exe that is run
# on a pose log (or spline trajectory) with the --log_dynamics input argument. This will output a 
# text file of the trajectory dynamics as a space separated list on each line with the following
# format:
# time_in_seconds linear_vel_x ... linear_vel_z angular_vel_x ... angular_vel_z linear_acc_x ... linear_acc_z angular_acc_x ... angular_acc_x
#
# This script takes a list of such dynamics files as input and generates plots
#
def ReadTrajectoryDynamics(filepath):
    timestamps = []
    velocities = []
    accelerations = []
    with open(filepath) as dynamicsFile:
        for lineString in dynamicsFile.readlines():
            line = lineString.split(' ')
            tokens = []
            for elem in line:
                if elem == '' or elem == '\n':
                    continue
                else:
                    tokens.append(float(elem))
            
            timestamps.append(tokens[0])
            velocity = np.array([tokens[1], tokens[2], tokens[3], tokens[4], tokens[5], tokens[6]])
            velocities.append(velocity)
            acceleration = np.array([tokens[7], tokens[8], tokens[9], tokens[10], tokens[11], tokens[12]])
            accelerations.append(acceleration)

    velocities = np.array(velocities)
    accelerations = np.array(accelerations)
    return timestamps, velocities, accelerations
    
def Main(trajectoryFilePaths):
    colors = ['r', 'g', 'b']
    for idx in range(0, len(trajectoryFilePaths)):
        timestamps, velocities, accelerations = ReadTrajectoryDynamics(trajectoryFilePaths[idx])
        plt.subplot(4,3,1)
        plt.plot(timestamps, velocities[:,0], colors[idx])
        plt.ylabel('Lin Vel X')
        plt.subplot(4,3,2)
        plt.plot(timestamps, velocities[:,1], colors[idx])
        plt.ylabel('Lin Vel Y')
        plt.subplot(4,3,3)
        plt.plot(timestamps, velocities[:,2], colors[idx])
        plt.ylabel('Lin Vel Z')
        plt.xlabel('Time (s)')
        plt.subplot(4,3,4)
        plt.plot(timestamps, velocities[:,3], colors[idx])
        plt.ylabel('Ang Vel X')
        plt.subplot(4,3,5)
        plt.plot(timestamps, velocities[:,4], colors[idx])
        plt.ylabel('Ang Vel Y')
        plt.subplot(4,3,6)
        plt.plot(timestamps, velocities[:,5], colors[idx])
        plt.ylabel('Ang Vel Z')
        plt.xlabel('Time (s)')

        # Accelerations
        plt.subplot(4,3,7)
        plt.plot(timestamps, accelerations[:,0], colors[idx])
        plt.ylabel('Lin Acc X')
        plt.subplot(4,3,8)
        plt.plot(timestamps, accelerations[:,1], colors[idx])
        plt.ylabel('Lin Acc Y')
        plt.subplot(4,3,9)
        plt.plot(timestamps, accelerations[:,2], colors[idx])
        plt.ylabel('Lin Acc Z')
        plt.xlabel('Time (s)')
        plt.subplot(4,3,10)
        plt.plot(timestamps, accelerations[:,3], colors[idx])
        plt.ylabel('Ang Acc X')
        plt.subplot(4,3,11)
        plt.plot(timestamps, accelerations[:,4], colors[idx])
        plt.ylabel('Ang Acc Y')
        plt.subplot(4,3,12)
        plt.plot(timestamps, accelerations[:,5], colors[idx])
        plt.ylabel('Ang Acc Z')
        plt.xlabel('Time (s)')

    plt.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PlotTrajectoryDynamics.py")
    parser.add_argument('--Trajectories', nargs='+', help="Paths to the file locations of trajectory dynamics. Default = None")
    args = parser.parse_args()
    sys.exit(Main(args.Trajectories))
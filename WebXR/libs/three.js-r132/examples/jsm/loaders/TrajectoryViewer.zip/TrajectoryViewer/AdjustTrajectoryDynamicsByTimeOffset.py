import argparse
import os
import sys
import numpy as np
import matplotlib.pyplot as plt

# This script is intended to be used in conjunction with the tool TrajectoryViewer.exe that is run
# on a pose log (or spline trajectory) with the --log_dynamics input argument. This will output a 
# text file of the trajectory dynamics as a space separated list on each line with the following
# format:
# time_in_seconds linear_vel_x ... linear_vel_z angular_vel_x ... angular_vel_z linear_acc_x ... linear_acc_z angular_acc_x ... angular_acc_x
#
# This script takes a list of such dynamics files as input and generates plots
#

def WriteTrajectoryDynamics(filepath, timestamps, velocities, accelerations):
    with open(filepath, "w") as dynamicsFile:
        for i in range(0, len(timestamps)):
            strToWrite = '%f %f %f %f %f %f %f %f %f %f %f %f %f\n' % (timestamps[i] 
            , velocities[i][0]
            , velocities[i][1]
            , velocities[i][2]
            , velocities[i][3]
            , velocities[i][4]
            , velocities[i][5]
            , accelerations[i][0]
            , accelerations[i][1]
            , accelerations[i][2]
            , accelerations[i][3]
            , accelerations[i][4]
            , accelerations[i][5])
            dynamicsFile.write(strToWrite)
    
def ReadTrajectoryDynamics(filepath):
    timestamps = []
    velocities = []
    accelerations = []
    with open(filepath) as dynamicsFile:
        for lineString in dynamicsFile.readlines():
            line = lineString.split(' ')
            tokens = []
            for elem in line:
                if elem == '' or elem == '\n':
                    continue
                else:
                    tokens.append(float(elem))
            
            timestamps.append(tokens[0])
            velocity = np.array([tokens[1], tokens[2], tokens[3], tokens[4], tokens[5], tokens[6]])
            velocities.append(velocity)
            acceleration = np.array([tokens[7], tokens[8], tokens[9], tokens[10], tokens[11], tokens[12]])
            accelerations.append(acceleration)

    velocities = np.array(velocities)
    accelerations = np.array(accelerations)
    return timestamps, velocities, accelerations

def ReadTimeOffset(filepath):
    offset = 0.0
    scale = 1.0
    with open(filepath, "r") as timeOffsetFile:
        contents = timeOffsetFile.readlines()
        offset = float(contents[0])
        scale = float(contents[1])
 
    return offset, scale
    
def Main(trajectoryFilePath, timeOffsetFilePath):
    timestamps, velocities, accelerations = ReadTrajectoryDynamics(trajectoryFilePath)
    offset, scale = ReadTimeOffset(timeOffsetFilePath)
       
    invscale = 1.0/scale
    modified_timestamps = (np.array(timestamps) - offset) * invscale
    
    tokens = os.path.splitext(trajectoryFilePath)
    modifiedTrajectoryFilePath = tokens[0] + "_modified" + tokens[1]
    WriteTrajectoryDynamics(modifiedTrajectoryFilePath, modified_timestamps, velocities, accelerations)
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AdjustTrajectoryDynamicsByTimeOffset.py")
    parser.add_argument('--DynamicsFile', help="Path to the file location of trajectory dynamics. Default = None")
    parser.add_argument('--TimeOffsetFile', help="Path to the file location of the time offset. Default = None")
    args = parser.parse_args()
    args.DynamicsFile = "C:\Sequences\8_6_smooth_g290\Output\optimized_spline_leftDynamics.txt"
    args.TimeOffsetFile = "C:/Sequences/8_6_smooth_g290/Output/time_offset.txt"
    sys.exit(Main(args.DynamicsFile, args.TimeOffsetFile))